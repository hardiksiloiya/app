export interface Details {
    name: string,
    email: string,
    feedback: string,
    comment: string,
}